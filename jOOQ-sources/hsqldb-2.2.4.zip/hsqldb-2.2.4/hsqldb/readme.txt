Readme File
$Date: 2011-06-06 18:22:05 -0400 (Mon, 06 Jun 2011) $
This package contains HyperSQL v. 2.2.4

HyperSQL is a relational database engine and a set of tools written in Java.
HyperSQL is also known as HSQLDB.

The file "index.html" explains the contents of this distribution and has
links to documentation and support resources.
