/*
 * Copyright 2002-2013 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springframework.samples.petclinic.repository.jooq;

import static org.springframework.samples.petclinic.jooq.Tables.PETS;
import static org.springframework.samples.petclinic.jooq.Tables.TYPES;

import java.util.List;

import javax.sql.DataSource;

import org.jooq.DSLContext;
import org.jooq.SQLDialect;
import org.jooq.impl.DSL;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.ObjectRetrievalFailureException;
import org.springframework.samples.petclinic.jooq.tables.records.PetsRecord;
import org.springframework.samples.petclinic.model.Owner;
import org.springframework.samples.petclinic.model.Pet;
import org.springframework.samples.petclinic.model.PetType;
import org.springframework.samples.petclinic.model.Visit;
import org.springframework.samples.petclinic.repository.OwnerRepository;
import org.springframework.samples.petclinic.repository.PetRepository;
import org.springframework.samples.petclinic.repository.VisitRepository;
import org.springframework.samples.petclinic.util.EntityUtils;
import org.springframework.stereotype.Repository;

/**
 * @author Ken Krebs
 * @author Juergen Hoeller
 * @author Rob Harrop
 * @author Sam Brannen
 * @author Thomas Risberg
 * @author Mark Fisher
 */
@Repository
public class JooqPetRepositoryImpl implements PetRepository {

    private OwnerRepository ownerRepository;
    private VisitRepository visitRepository;
    private DSLContext ctx;
    
    @Autowired
    public JooqPetRepositoryImpl(DataSource dataSource, OwnerRepository ownerRepository, VisitRepository visitRepository) {
        this.ctx = DSL.using(dataSource, SQLDialect.HSQLDB);
        this.ownerRepository = ownerRepository;
        this.visitRepository = visitRepository;
    }

    @Override
    public List<PetType> findPetTypes() throws DataAccessException {
        return ctx.selectFrom(TYPES).orderBy(TYPES.NAME).fetchInto(PetType.class);
    }

    @Override
    public Pet findById(int id) throws DataAccessException {
        JooqPet pet = ctx.selectFrom(PETS).where(PETS.ID.eq(id)).fetchOneInto(JooqPet.class);
        if (pet == null)
            throw new ObjectRetrievalFailureException(Pet.class, new Integer(id));
        
        Owner owner = this.ownerRepository.findById(pet.getOwnerId());
        owner.addPet(pet);
        pet.setType(EntityUtils.getById(findPetTypes(), PetType.class, pet.getTypeId()));

        List<Visit> visits = this.visitRepository.findByPetId(pet.getId());
        for (Visit visit : visits) {
            pet.addVisit(visit);
        }
        return pet;
    }

    @Override
    public void save(Pet pet) throws DataAccessException {
        PetsRecord record = ctx.newRecord(PETS, pet);
        
        if (pet.isNew()) {
        	record.insert();
        	pet.setId(record.getId());
        } else {
        	record.update();
        }
    }
}
