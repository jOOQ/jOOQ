/*
 * Copyright 2002-2013 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springframework.samples.petclinic.repository.jooq;

import static org.springframework.samples.petclinic.jooq.Tables.SPECIALTIES;
import static org.springframework.samples.petclinic.jooq.Tables.VETS;
import static org.springframework.samples.petclinic.jooq.Tables.VET_SPECIALTIES;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.sql.DataSource;

import org.jooq.DSLContext;
import org.jooq.SQLDialect;
import org.jooq.impl.DSL;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.samples.petclinic.jooq.Tables;
import org.springframework.samples.petclinic.model.Specialty;
import org.springframework.samples.petclinic.model.Vet;
import org.springframework.samples.petclinic.repository.VetRepository;
import org.springframework.samples.petclinic.util.EntityUtils;
import org.springframework.stereotype.Repository;

/**
 * A simple JDBC-based implementation of the {@link VetRepository} interface. Uses @Cacheable to cache the result of the
 * {@link findAll} method
 *
 * @author Ken Krebs
 * @author Juergen Hoeller
 * @author Rob Harrop
 * @author Sam Brannen
 * @author Thomas Risberg
 * @author Mark Fisher
 * @author Michael Isvy
 * @author Lukas Eder
 */
@Repository
public class JooqVetRepositoryImpl implements VetRepository {

    private DSLContext ctx;

    @Autowired
    public JooqVetRepositoryImpl(DataSource dataSource) {
        this.ctx = DSL.using(dataSource, SQLDialect.HSQLDB);
    }

    /**
     * Refresh the cache of Vets that the ClinicService is holding.
     *
     * @see org.springframework.samples.petclinic.model.service.ClinicService#shouldFindVets()
     */
    @Override
    public Collection<Vet> findAll() throws DataAccessException {
        List<Vet> vets = ctx.selectFrom(VETS).orderBy(VETS.LAST_NAME, VETS.FIRST_NAME).fetchInto(Vet.class);

        // Retrieve the list of all possible specialties.
        final List<Specialty> specialties = ctx.fetch(SPECIALTIES).into(Specialty.class); 

        // Build each vet's list of specialties.
        for (Vet vet : vets) {
            final List<Integer> vetSpecialtiesIds = ctx
        		.select(VET_SPECIALTIES.SPECIALTY_ID)
        		.from(VET_SPECIALTIES)
        		.where(VET_SPECIALTIES.VET_ID.eq(vet.getId()))
        		.fetchInto(Integer.class);
            
            for (int specialtyId : vetSpecialtiesIds) {
                Specialty specialty = EntityUtils.getById(specialties, Specialty.class, specialtyId);
                vet.addSpecialty(specialty);
            }
        }
        return vets;
    }
}
