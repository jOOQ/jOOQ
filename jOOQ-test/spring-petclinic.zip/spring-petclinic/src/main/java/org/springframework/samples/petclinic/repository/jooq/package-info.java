
/**
 *
 * The classes in this package represent the jOOQ implementation
 * of PetClinic's persistence layer.
 *
 */
package org.springframework.samples.petclinic.repository.jooq;

