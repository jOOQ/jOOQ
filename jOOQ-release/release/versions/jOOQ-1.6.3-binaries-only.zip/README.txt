Thanks for downloading jOOQ.
Please visit http://jooq.sourceforge.net for more information.