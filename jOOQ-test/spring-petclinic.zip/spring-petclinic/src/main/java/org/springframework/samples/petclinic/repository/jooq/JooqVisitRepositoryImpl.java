/*
 * Copyright 2002-2013 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springframework.samples.petclinic.repository.jooq;

import static org.springframework.samples.petclinic.jooq.Tables.PETS;
import static org.springframework.samples.petclinic.jooq.Tables.VISITS;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.joda.time.DateTime;
import org.jooq.DSLContext;
import org.jooq.SQLDialect;
import org.jooq.impl.DSL;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.samples.petclinic.jooq.Tables;
import org.springframework.samples.petclinic.jooq.tables.records.PetsRecord;
import org.springframework.samples.petclinic.jooq.tables.records.VisitsRecord;
import org.springframework.samples.petclinic.model.Visit;
import org.springframework.samples.petclinic.repository.VisitRepository;
import org.springframework.stereotype.Repository;

/**
 * A simple JDBC-based implementation of the {@link VisitRepository} interface.
 *
 * @author Ken Krebs
 * @author Juergen Hoeller
 * @author Rob Harrop
 * @author Sam Brannen
 * @author Thomas Risberg
 * @author Mark Fisher
 * @author Michael Isvy
 * @author Lukas Eder
 */
@Repository
public class JooqVisitRepositoryImpl implements VisitRepository {

    private DSLContext ctx;
    
    @Autowired
    public JooqVisitRepositoryImpl(DataSource dataSource) {
        this.ctx = DSL.using(dataSource, SQLDialect.HSQLDB);
    }

    @Override
    public void save(Visit visit) throws DataAccessException {
        VisitsRecord record = ctx.newRecord(VISITS, visit);
        
        if (visit.isNew()) {
        	record.insert();
        	visit.setId(record.getId());
        } else {
        	record.update();
        }
    }

    public void deletePet(int id) throws DataAccessException {
    	ctx.delete(PETS).where(PETS.ID.eq(id)).execute();
    }

    @Override
    public List<Visit> findByPetId(Integer petId) {
    	return
    	ctx.select(VISITS.ID, VISITS.VISIT_DATE, VISITS.DESCRIPTION)
    	   .from(VISITS)
    	   .where(VISITS.PET_ID.eq(petId))
    	   .fetchInto(Visit.class);
    }
}
